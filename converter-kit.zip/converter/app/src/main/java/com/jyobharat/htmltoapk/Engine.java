package com.jyobharat.htmltoapk;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;

import com.android.apksig.ApkSigner;

import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FilterOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.MessageDigest;
import java.security.PrivateKey;
import java.security.SecureRandom;
import java.security.Signature;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.Arrays;
import java.util.Collections;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.CRC32;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;

/**
 * Phone ke andar APK banata hai: assets/template.apk ko kholta hai, HTML / config / icons / naam
 * badalta hai, phir apksig se sign karta hai. Koi server nahi.
 */
final class Engine {

    interface Progress { void on(int pct, String msg); }

    private static final String PKG_PH = "com.jyobharat.webapp";
    private static final String NAME_PH = "APPNAME_PLACEHOLDER";
    private static final int MAX = 5 * 1024 * 1024;
    private static final List<String> SPLASH = Arrays.asList("none", "default", "s1", "s2", "s3", "s4", "s5");
    private static final Pattern ICON =
            Pattern.compile("^res/mipmap-(mdpi|hdpi|xhdpi|xxhdpi|xxxhdpi)[^/]*/ic_launcher\\.png$");
    private static final Map<String, Integer> DENS = new HashMap<>();
    static {
        DENS.put("mdpi", 48);
        DENS.put("hdpi", 72);
        DENS.put("xhdpi", 96);
        DENS.put("xxhdpi", 144);
        DENS.put("xxxhdpi", 192);
    }

    private Engine() { }

    static File build(Context ctx, JSONObject in, byte[] html, byte[] logo, Progress pr) throws Exception {
        pr.on(5, "Checking your HTML...");
        if (html.length == 0 || html.length > MAX) throw new Exception("The HTML file must be 5 MB or smaller.");

        String name = in.optString("appName", "").replaceAll("\\p{Cntrl}", "").trim();
        if (name.isEmpty()) name = "My App";
        if (name.length() > 30) name = name.substring(0, 30);
        String sp = in.optString("splash", "default");
        if (!SPLASH.contains(sp)) sp = "default";
        String sc = color(in.optString("statusColor", ""), "#FFFFFF");
        String nc = color(in.optString("navColor", ""), sc);
        JSONObject cfg = new JSONObject();
        cfg.put("appName", name);
        cfg.put("splash", sp);
        cfg.put("fullscreen", in.optBoolean("fullscreen", false));
        cfg.put("statusColor", sc);
        cfg.put("navColor", nc);

        pr.on(15, "Creating icons...");
        Bitmap sq = null;
        if (logo != null) {
            if (logo.length > MAX) throw new Exception("The logo must be 5 MB or smaller.");
            Bitmap b = BitmapFactory.decodeByteArray(logo, 0, logo.length);
            if (b == null) throw new Exception("The logo image could not be read.");
            sq = square(b);
        }

        pr.on(30, "Applying settings...");
        File tpl = new File(ctx.getCacheDir(), "template.apk");
        try (InputStream i = ctx.getAssets().open("template.apk"); OutputStream o = new FileOutputStream(tpl)) {
            copy(i, o);
        }
        String pkg = "com.htmlapk.app" + sha(name).substring(0, 10);
        byte[] manifest;
        try (ZipFile zf = new ZipFile(tpl)) {
            manifest = patchManifest(readAll(zf.getInputStream(zf.getEntry("AndroidManifest.xml"))), pkg, name);
        }
        File unsigned = new File(ctx.getCacheDir(), "unsigned.apk");
        rewrite(tpl, unsigned, manifest, cfg.toString(2).getBytes(StandardCharsets.UTF_8), html, sq);

        pr.on(60, "Signing the APK...");
        File dir = new File(ctx.getFilesDir(), "out");
        dir.mkdirs();
        String safe = name.replaceAll("[^\\p{L}\\p{N} _-]", "").trim();
        if (safe.isEmpty()) safe = "app";
        File out = new File(dir, safe + ".apk");
        if (out.exists()) out.delete();
        sign(ctx, unsigned, out);
        unsigned.delete();

        pr.on(100, "Done");
        return out;
    }

    // ---------- helpers ----------
    private static String color(String s, String def) {
        return s.matches("^#[0-9A-Fa-f]{6}$") ? s.toUpperCase() : def;
    }

    private static String sha(String s) throws Exception {
        byte[] d = MessageDigest.getInstance("SHA-256").digest(s.getBytes(StandardCharsets.UTF_8));
        StringBuilder sb = new StringBuilder();
        for (byte x : d) sb.append(String.format("%02x", x));
        return sb.toString();
    }

    private static void copy(InputStream i, OutputStream o) throws IOException {
        byte[] buf = new byte[16384];
        int n;
        while ((n = i.read(buf)) > 0) o.write(buf, 0, n);
    }

    private static byte[] readAll(InputStream i) throws IOException {
        try (InputStream in = i) {
            ByteArrayOutputStream o = new ByteArrayOutputStream();
            copy(in, o);
            return o.toByteArray();
        }
    }

    private static Bitmap square(Bitmap b) {
        int s = Math.max(b.getWidth(), b.getHeight());
        Bitmap o = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888);
        new Canvas(o).drawBitmap(b, (s - b.getWidth()) / 2f, (s - b.getHeight()) / 2f, null);
        return o;
    }

    private static byte[] png(Bitmap sq, int size) {
        Bitmap r = Bitmap.createScaledBitmap(sq, size, size, true);
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        r.compress(Bitmap.CompressFormat.PNG, 100, o);
        return o.toByteArray();
    }

    // ---------- binary manifest (AXML) patch: string pool rewrite ----------
    static byte[] patchManifest(byte[] m, String pkg, String label) throws Exception {
        ByteBuffer b = ByteBuffer.wrap(m).order(ByteOrder.LITTLE_ENDIAN);
        if (b.getShort(0) != 0x0003 || b.getShort(8) != 0x0001) throw new Exception("Unexpected template manifest.");
        int po = 8;
        int psz = b.getInt(po + 4);
        int n = b.getInt(po + 8);
        int nst = b.getInt(po + 12);
        int flags = b.getInt(po + 16);
        int ss = b.getInt(po + 20);
        if (nst != 0) throw new Exception("Template manifest has styled strings.");
        boolean u8 = (flags & 0x100) != 0;

        ByteArrayOutputStream sd = new ByteArrayOutputStream();
        int[] offs = new int[n];
        int hits = 0;
        for (int i = 0; i < n; i++) {
            int p = po + ss + b.getInt(po + 28 + 4 * i);
            String s;
            if (u8) {
                int c = m[p++] & 0xFF;
                if ((c & 0x80) != 0) p++;
                int bl = m[p++] & 0xFF;
                if ((bl & 0x80) != 0) bl = ((bl & 0x7F) << 8) | (m[p++] & 0xFF);
                s = new String(m, p, bl, StandardCharsets.UTF_8);
            } else {
                int c = b.getShort(p) & 0xFFFF;
                p += 2;
                if ((c & 0x8000) != 0) {
                    c = ((c & 0x7FFF) << 16) | (b.getShort(p) & 0xFFFF);
                    p += 2;
                }
                s = new String(m, p, c * 2, StandardCharsets.UTF_16LE);
            }
            if (s.equals(PKG_PH)) { s = pkg; hits++; }
            else if (s.equals(NAME_PH)) { s = label; hits++; }

            offs[i] = sd.size();
            if (u8) {
                byte[] bytes = s.getBytes(StandardCharsets.UTF_8);
                putLen8(sd, s.length());
                putLen8(sd, bytes.length);
                sd.write(bytes);
                sd.write(0);
            } else {
                int len = s.length();
                if (len > 0x7FFF) {
                    putShort(sd, ((len >> 16) & 0x7FFF) | 0x8000);
                    putShort(sd, len & 0xFFFF);
                } else {
                    putShort(sd, len);
                }
                sd.write(s.getBytes(StandardCharsets.UTF_16LE));
                putShort(sd, 0);
            }
        }
        if (hits != 2) throw new Exception("Template manifest placeholders not found.");
        while (sd.size() % 4 != 0) sd.write(0);

        int newPool = 28 + 4 * n + sd.size();
        int restOff = 8 + psz;
        int restLen = m.length - restOff;
        ByteBuffer o = ByteBuffer.allocate(8 + newPool + restLen).order(ByteOrder.LITTLE_ENDIAN);
        o.putShort((short) 0x0003).putShort((short) 8).putInt(8 + newPool + restLen);
        o.putShort((short) 0x0001).putShort((short) 28).putInt(newPool).putInt(n).putInt(0)
                .putInt(flags).putInt(28 + 4 * n).putInt(0);
        for (int off : offs) o.putInt(off);
        o.put(sd.toByteArray());
        o.put(m, restOff, restLen);
        return o.array();
    }

    private static void putLen8(ByteArrayOutputStream o, int len) {
        if (len > 0x7F) {
            o.write(((len >> 8) & 0x7F) | 0x80);
            o.write(len & 0xFF);
        } else {
            o.write(len);
        }
    }

    private static void putShort(ByteArrayOutputStream o, int v) {
        o.write(v & 0xFF);
        o.write((v >> 8) & 0xFF);
    }

    // ---------- zip rebuild (resources.arsc 4-byte aligned) ----------
    private static final class Counting extends FilterOutputStream {
        long n;
        Counting(OutputStream o) { super(o); }
        @Override public void write(int b) throws IOException { out.write(b); n++; }
        @Override public void write(byte[] b, int off, int len) throws IOException { out.write(b, off, len); n += len; }
    }

    private static void rewrite(File tpl, File dst, byte[] manifest, byte[] cfg, byte[] html, Bitmap sq)
            throws IOException {
        try (ZipFile zf = new ZipFile(tpl);
             Counting co = new Counting(new FileOutputStream(dst));
             ZipOutputStream z = new ZipOutputStream(co)) {
            for (Enumeration<? extends ZipEntry> en = zf.entries(); en.hasMoreElements(); ) {
                ZipEntry e = en.nextElement();
                String n = e.getName();
                if (e.isDirectory() || n.startsWith("META-INF/") || n.equals("assets/logo.png")) continue;
                byte[] d = readAll(zf.getInputStream(e));
                if (n.equals("AndroidManifest.xml")) d = manifest;
                else if (n.equals("assets/index.html")) d = html;
                else if (n.equals("assets/config.json")) d = cfg;
                else if (sq != null) {
                    Matcher m = ICON.matcher(n);
                    if (m.matches()) d = png(sq, DENS.get(m.group(1)));
                }
                put(z, co, n, d, e.getMethod() == ZipEntry.STORED);
            }
            if (sq != null) put(z, co, "assets/logo.png", png(sq, 512), false);
        }
    }

    private static void put(ZipOutputStream z, Counting co, String n, byte[] d, boolean stored)
            throws IOException {
        ZipEntry e = new ZipEntry(n);
        if (stored) {
            e.setMethod(ZipEntry.STORED);
            e.setSize(d.length);
            e.setCompressedSize(d.length);
            CRC32 c = new CRC32();
            c.update(d);
            e.setCrc(c.getValue());
            int r = (int) ((4 - ((co.n + 30 + n.getBytes(StandardCharsets.UTF_8).length) & 3)) & 3);
            if (r != 0) {
                byte[] x = new byte[r + 4];
                x[0] = 0x35;
                x[1] = (byte) 0xD9;
                x[2] = (byte) r;
                e.setExtra(x);
            }
        } else {
            e.setMethod(ZipEntry.DEFLATED);
        }
        z.putNextEntry(e);
        z.write(d);
        z.closeEntry();
    }

    // ---------- signing (key ek baar banti hai, phir save rehti hai) ----------
    private static void sign(Context ctx, File in, File out) throws Exception {
        File kf = new File(ctx.getFilesDir(), "key.pk8");
        File cf = new File(ctx.getFilesDir(), "cert.der");
        PrivateKey pk;
        byte[] certBytes;
        if (kf.exists() && cf.exists()) {
            pk = KeyFactory.getInstance("RSA").generatePrivate(new PKCS8EncodedKeySpec(readAll(new FileInputStream(kf))));
            certBytes = readAll(new FileInputStream(cf));
        } else {
            KeyPairGenerator g = KeyPairGenerator.getInstance("RSA");
            g.initialize(2048);
            KeyPair kp = g.generateKeyPair();
            pk = kp.getPrivate();
            certBytes = selfSign(kp);
            try (FileOutputStream o = new FileOutputStream(kf)) { o.write(pk.getEncoded()); }
            try (FileOutputStream o = new FileOutputStream(cf)) { o.write(certBytes); }
        }
        X509Certificate cert = (X509Certificate) CertificateFactory.getInstance("X.509")
                .generateCertificate(new ByteArrayInputStream(certBytes));
        ApkSigner.SignerConfig sc = new ApkSigner.SignerConfig.Builder("key", pk, Collections.singletonList(cert)).build();
        new ApkSigner.Builder(Collections.singletonList(sc))
                .setInputApk(in)
                .setOutputApk(out)
                .setMinSdkVersion(21)
                .setV1SigningEnabled(true)
                .setV2SigningEnabled(true)
                .setV3SigningEnabled(false)
                .build()
                .sign();
    }

    private static byte[] selfSign(KeyPair kp) throws Exception {
        byte[] alg = tlv(0x30, cat(new byte[]{6, 9, 0x2A, (byte) 0x86, 0x48, (byte) 0x86, (byte) 0xF7, 0x0D, 1, 1, 0x0B},
                new byte[]{5, 0}));
        byte[] name = tlv(0x30, tlv(0x31, tlv(0x30, cat(new byte[]{6, 3, 0x55, 4, 3},
                tlv(0x0C, "HTML to APK".getBytes(StandardCharsets.UTF_8))))));
        byte[] val = tlv(0x30, cat(tlv(0x17, "250101000000Z".getBytes(StandardCharsets.UTF_8)),
                tlv(0x18, "20550101000000Z".getBytes(StandardCharsets.UTF_8))));
        byte[] serial = new byte[8];
        new SecureRandom().nextBytes(serial);
        serial[0] = (byte) ((serial[0] & 0x7F) | 0x40);
        byte[] tbs = tlv(0x30, cat(new byte[]{(byte) 0xA0, 3, 2, 1, 2}, tlv(2, serial), alg, name, val, name,
                kp.getPublic().getEncoded()));
        Signature s = Signature.getInstance("SHA256withRSA");
        s.initSign(kp.getPrivate());
        s.update(tbs);
        byte[] sig = s.sign();
        return tlv(0x30, cat(tbs, alg, tlv(3, cat(new byte[]{0}, sig))));
    }

    private static byte[] tlv(int tag, byte[] v) {
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        o.write(tag);
        int l = v.length;
        if (l < 128) {
            o.write(l);
        } else if (l < 256) {
            o.write(0x81);
            o.write(l);
        } else {
            o.write(0x82);
            o.write(l >> 8);
            o.write(l & 0xFF);
        }
        o.write(v, 0, v.length);
        return o.toByteArray();
    }

    private static byte[] cat(byte[]... parts) {
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        for (byte[] p : parts) o.write(p, 0, p.length);
        return o.toByteArray();
    }
}
