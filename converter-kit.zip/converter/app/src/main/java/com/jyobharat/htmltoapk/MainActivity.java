package com.jyobharat.htmltoapk;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.View;
import android.view.Window;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.core.content.FileProvider;

import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

public class MainActivity extends Activity {

    private static final int FILE_REQ = 1;
    private WebView web;
    private ValueCallback<Uri[]> chooser;
    private File lastApk;

    @Override
    @SuppressWarnings("deprecation")
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Window w = getWindow();
        w.setStatusBarColor(0xFF2A1FD6);
        w.setNavigationBarColor(0xFFECEBFF);
        w.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);

        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                return !"file".equals(r.getUrl().getScheme());
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> cb,
                                             FileChooserParams p) {
                if (chooser != null) chooser.onReceiveValue(null);
                chooser = cb;
                try {
                    startActivityForResult(p.createIntent(), FILE_REQ);
                } catch (Exception e) {
                    chooser = null;
                    return false;
                }
                return true;
            }
        });
        web.addJavascriptInterface(new Bridge(), "ApkEngine");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == FILE_REQ && chooser != null) {
            chooser.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res, data));
            chooser = null;
        }
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        if (web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }

    private void js(final String code) {
        runOnUiThread(() -> web.evaluateJavascript(code, null));
    }

    private void toast(final String m) {
        runOnUiThread(() -> Toast.makeText(this, m, Toast.LENGTH_LONG).show());
    }

    /** JavaScript ka "ApkEngine" object. */
    private class Bridge {

        @JavascriptInterface
        public void build(final String cfg, final String htmlB64, final String logoB64) {
            new Thread(() -> {
                try {
                    JSONObject c = new JSONObject(cfg);
                    byte[] html = Base64.decode(htmlB64, Base64.DEFAULT);
                    byte[] logo = logoB64.isEmpty() ? null : Base64.decode(logoB64, Base64.DEFAULT);
                    File out = Engine.build(MainActivity.this, c, html, logo,
                            (p, m) -> js("onBuildProgress(" + p + "," + JSONObject.quote(m) + ")"));
                    lastApk = out;
                    js("onBuildDone(" + out.length() + ")");
                } catch (Throwable e) {
                    String m = e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage();
                    js("onBuildError(" + JSONObject.quote(m) + ")");
                }
            }).start();
        }

        @JavascriptInterface
        public void download() {
            if (lastApk == null) return;
            new Thread(() -> {
                try {
                    String name = lastApk.getName();
                    if (Build.VERSION.SDK_INT >= 29) {
                        ContentValues v = new ContentValues();
                        v.put(MediaStore.Downloads.DISPLAY_NAME, name);
                        v.put(MediaStore.Downloads.MIME_TYPE, "application/vnd.android.package-archive");
                        v.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                        Uri u = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                        copy(lastApk, getContentResolver().openOutputStream(u));
                        toast("Saved to Downloads: " + name);
                    } else {
                        File d = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
                        File f = new File(d, name);
                        copy(lastApk, new FileOutputStream(f));
                        toast("Saved: " + f.getAbsolutePath());
                    }
                } catch (Exception e) {
                    toast("Could not save the APK.");
                }
            }).start();
        }

        @JavascriptInterface
        public void share() {
            if (lastApk == null) return;
            runOnUiThread(() -> {
                try {
                    Uri u = FileProvider.getUriForFile(MainActivity.this,
                            getPackageName() + ".fp", lastApk);
                    Intent i = new Intent(Intent.ACTION_SEND);
                    i.setType("application/vnd.android.package-archive");
                    i.putExtra(Intent.EXTRA_STREAM, u);
                    i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    startActivity(Intent.createChooser(i, "Share APK"));
                } catch (Exception e) {
                    toast("Could not share the APK.");
                }
            });
        }
    }

    private static void copy(File src, OutputStream out) throws Exception {
        try (InputStream in = new FileInputStream(src); OutputStream o = out) {
            byte[] buf = new byte[16384];
            int n;
            while ((n = in.read(buf)) > 0) o.write(buf, 0, n);
        }
    }
}
