package com.jyobharat.webapp;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;

public class MainActivity extends Activity {

    private static final int FILE_REQ = 1001;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private JSONObject cfg = new JSONObject();
    private FrameLayout root;
    private WebView web;
    private SplashView splash;
    private ValueCallback<Uri[]> filePathCallback;
    private boolean pageLoaded = false;
    private boolean minTimePassed = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        cfg = readConfig();

        root = new FrameLayout(this);
        root.setBackgroundColor(Color.WHITE);
        web = new WebView(this);
        root.addView(web, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);

        setupBars();
        setupWebView();
        setupSplash();

        web.loadUrl("file:///android_asset/index.html");
    }

    // ---------- config ----------
    private JSONObject readConfig() {
        try (InputStream is = getAssets().open("config.json")) {
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            byte[] buf = new byte[4096];
            int n;
            while ((n = is.read(buf)) > 0) bos.write(buf, 0, n);
            return new JSONObject(bos.toString("UTF-8"));
        } catch (Exception e) {
            return new JSONObject();
        }
    }

    private int color(String s, int def) {
        try { return Color.parseColor(s); } catch (Exception e) { return def; }
    }

    private boolean isLight(int c) {
        return (0.299 * Color.red(c) + 0.587 * Color.green(c) + 0.114 * Color.blue(c)) > 160;
    }

    // ---------- status / navigation bar ----------
    private boolean fullscreen() {
        return cfg.optBoolean("fullscreen", false);
    }

    @SuppressWarnings("deprecation")
    private void setupBars() {
        Window w = getWindow();
        if (fullscreen()) {
            if (Build.VERSION.SDK_INT >= 28) {
                WindowManager.LayoutParams lp = w.getAttributes();
                lp.layoutInDisplayCutoutMode =
                        WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
                w.setAttributes(lp);
            }
            hideBars();
        } else {
            String st = cfg.optString("statusColor", "#FFFFFF");
            int sc = color(st, Color.WHITE);
            int nc = color(cfg.optString("navColor", st), Color.WHITE);
            w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            w.setStatusBarColor(sc);
            w.setNavigationBarColor(nc);
            int flags = w.getDecorView().getSystemUiVisibility();
            if (Build.VERSION.SDK_INT >= 23) {
                if (isLight(sc)) flags |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
                else flags &= ~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
            }
            if (Build.VERSION.SDK_INT >= 26) {
                if (isLight(nc)) flags |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
                else flags &= ~View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
            }
            w.getDecorView().setSystemUiVisibility(flags);
        }
    }

    @SuppressWarnings("deprecation")
    private void hideBars() {
        Window w = getWindow();
        if (Build.VERSION.SDK_INT >= 30) {
            w.setDecorFitsSystemWindows(false);
            WindowInsetsController c = w.getInsetsController();
            if (c != null) {
                c.hide(WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
                c.setSystemBarsBehavior(
                        WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            }
        } else {
            w.getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus && fullscreen()) hideBars();
    }

    // ---------- WebView ----------
    private void setupWebView() {
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                String sch = u.getScheme();
                if ("http".equals(sch) || "https".equals(sch) || "file".equals(sch)) {
                    return false;
                }
                try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (Exception ignored) { }
                return true;
            }

            @Override
            public void onPageFinished(WebView v, String url) {
                pageLoaded = true;
                maybeHideSplash();
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> cb,
                                             FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = cb;
                try {
                    startActivityForResult(params.createIntent(), FILE_REQ);
                } catch (Exception e) {
                    filePathCallback = null;
                    return false;
                }
                return true;
            }
        });

        web.setDownloadListener((url, ua, cd, mime, len) -> {
            try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); }
            catch (Exception ignored) { }
        });
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == FILE_REQ && filePathCallback != null) {
            filePathCallback.onReceiveValue(
                    WebChromeClient.FileChooserParams.parseResult(res, data));
            filePathCallback = null;
        }
    }

    // ---------- splash ----------
    private Bitmap loadLogo() {
        Bitmap b = null;
        try (InputStream is = getAssets().open("logo.png")) {
            b = BitmapFactory.decodeStream(is);
        } catch (Exception ignored) { }
        if (b == null) b = BitmapFactory.decodeResource(getResources(), R.mipmap.ic_launcher);
        return b;
    }

    private void setupSplash() {
        String style = cfg.optString("splash", "default");
        if ("none".equals(style)) {
            minTimePassed = true;
            return;
        }
        splash = new SplashView(this, style, loadLogo(), cfg.optString("appName", "My App"));
        root.addView(splash, new FrameLayout.LayoutParams(-1, -1));
        long minMs = "default".equals(style) ? 700 : 2300;
        handler.postDelayed(() -> { minTimePassed = true; maybeHideSplash(); }, minMs);
        // safety: 8 sec ke baad splash zaroor hatao
        handler.postDelayed(() -> { pageLoaded = true; minTimePassed = true; maybeHideSplash(); }, 8000);
    }

    private void maybeHideSplash() {
        if (splash == null || !pageLoaded || !minTimePassed) return;
        final SplashView sv = splash;
        splash = null;
        sv.animate().alpha(0f).setDuration(350).withEndAction(() -> root.removeView(sv)).start();
    }

    // ---------- lifecycle ----------
    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        if (web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onPause() { super.onPause(); web.onPause(); }

    @Override
    protected void onResume() { super.onResume(); web.onResume(); }

    @Override
    protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        web.destroy();
        super.onDestroy();
    }
}
