package com.jyobharat.webapp;

import android.animation.Animator;
import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.animation.BounceInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.LinearInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/** default + 5 animated splash screens. Sab code se bante hain, extra library nahi. */
public class SplashView extends FrameLayout {

    private final float dp;
    private final Bitmap logo;
    private final String name;
    private final List<Animator> anims = new ArrayList<>();
    private Runnable onStart;

    public SplashView(Context ctx, String style, Bitmap logo, String name) {
        super(ctx);
        this.dp = ctx.getResources().getDisplayMetrics().density;
        this.logo = logo;
        this.name = name;
        setClickable(true); // neeche WebView ko touch na jaye
        switch (style) {
            case "s1": styleFade(); break;
            case "s2": stylePulse(); break;
            case "s3": styleSlide(); break;
            case "s4": styleSpin(); break;
            case "s5": styleBar(); break;
            default: styleDefault();
        }
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        if (onStart != null) onStart.run();
    }

    @Override
    protected void onDetachedFromWindow() {
        for (Animator a : anims) a.cancel();
        super.onDetachedFromWindow();
    }

    // ---------- helpers ----------
    private int px(int v) { return Math.round(v * dp); }

    private LinearLayout.LayoutParams lp(int w, int h) {
        return new LinearLayout.LayoutParams(w > 0 ? px(w) : w, h > 0 ? px(h) : h);
    }

    private void gradient(int c1, int c2, GradientDrawable.Orientation o) {
        setBackground(new GradientDrawable(o, new int[]{c1, c2}));
    }

    private LinearLayout column() {
        LinearLayout l = new LinearLayout(getContext());
        l.setOrientation(LinearLayout.VERTICAL);
        l.setGravity(Gravity.CENTER);
        addView(l, new FrameLayout.LayoutParams(-1, -1));
        return l;
    }

    private ImageView logoView() {
        ImageView iv = new ImageView(getContext());
        iv.setImageBitmap(logo);
        iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
        return iv;
    }

    private TextView label(String t, int sp, int color, boolean bold) {
        TextView tv = new TextView(getContext());
        tv.setText(t);
        tv.setTextSize(sp);
        tv.setTextColor(color);
        tv.setGravity(Gravity.CENTER);
        tv.setTypeface(bold ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT);
        return tv;
    }

    private void gap(LinearLayout l, int h) {
        l.addView(new View(getContext()), lp(1, h));
    }

    private GradientDrawable rounded(int color, int radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(px(radiusDp));
        return g;
    }

    private <T extends Animator> T keep(T a) {
        anims.add(a);
        return a;
    }

    // ---------- Default: logo + rolling loader + "Loading..." ----------
    private void styleDefault() {
        setBackgroundColor(Color.WHITE);
        LinearLayout c = column();
        c.addView(logoView(), lp(96, 96));
        gap(c, 28);
        ProgressBar pb = new ProgressBar(getContext());
        pb.setIndeterminate(true);
        pb.setIndeterminateTintList(ColorStateList.valueOf(Color.parseColor("#444444")));
        c.addView(pb, lp(36, 36));
        gap(c, 14);
        c.addView(label("Loading...", 15, Color.parseColor("#555555"), false), lp(-2, -2));
    }

    // ---------- S1: Fade + Scale ----------
    private void styleFade() {
        gradient(Color.parseColor("#0F2027"), Color.parseColor("#2C5364"),
                GradientDrawable.Orientation.TOP_BOTTOM);
        LinearLayout c = column();
        final ImageView lg = logoView();
        c.addView(lg, lp(110, 110));
        gap(c, 20);
        final TextView t = label(name, 22, Color.WHITE, true);
        c.addView(t, lp(-2, -2));
        lg.setAlpha(0f); lg.setScaleX(0.5f); lg.setScaleY(0.5f);
        t.setAlpha(0f); t.setTranslationY(px(24));
        onStart = () -> {
            lg.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(900)
                    .setInterpolator(new OvershootInterpolator()).start();
            t.animate().alpha(1f).translationY(0f).setStartDelay(450).setDuration(700).start();
        };
    }

    // ---------- S2: Pulse rings ----------
    private static class PulseView extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final ValueAnimator va = ValueAnimator.ofFloat(0f, 1f);
        private float t;

        PulseView(Context c) {
            super(c);
            p.setStyle(Paint.Style.STROKE);
            p.setColor(Color.WHITE);
            p.setStrokeWidth(3 * c.getResources().getDisplayMetrics().density);
            va.setDuration(2000);
            va.setRepeatCount(ValueAnimator.INFINITE);
            va.setInterpolator(new LinearInterpolator());
            va.addUpdateListener(a -> { t = (float) a.getAnimatedValue(); invalidate(); });
        }

        @Override protected void onAttachedToWindow() { super.onAttachedToWindow(); va.start(); }
        @Override protected void onDetachedFromWindow() { va.cancel(); super.onDetachedFromWindow(); }

        @Override
        protected void onDraw(Canvas canvas) {
            float cx = getWidth() / 2f, cy = getHeight() / 2f;
            float max = Math.min(getWidth(), getHeight()) / 2f;
            for (int i = 0; i < 3; i++) {
                float f = (t + i / 3f) % 1f;
                p.setAlpha((int) (255 * (1f - f) * 0.8f));
                canvas.drawCircle(cx, cy, max * (0.35f + 0.65f * f), p);
            }
        }
    }

    private void stylePulse() {
        gradient(Color.parseColor("#1A0B3B"), Color.parseColor("#5B2A86"),
                GradientDrawable.Orientation.TL_BR);
        LinearLayout c = column();
        FrameLayout holder = new FrameLayout(getContext());
        holder.addView(new PulseView(getContext()), new FrameLayout.LayoutParams(-1, -1));
        FrameLayout.LayoutParams flp = new FrameLayout.LayoutParams(px(96), px(96));
        flp.gravity = Gravity.CENTER;
        holder.addView(logoView(), flp);
        c.addView(holder, lp(260, 260));
        gap(c, 8);
        c.addView(label(name, 20, Color.WHITE, true), lp(-2, -2));
    }

    // ---------- S3: Slide up + bounce ----------
    private void styleSlide() {
        gradient(Color.parseColor("#FF512F"), Color.parseColor("#F09819"),
                GradientDrawable.Orientation.TL_BR);
        LinearLayout c = column();
        final ImageView lg = logoView();
        c.addView(lg, lp(110, 110));
        gap(c, 20);
        final TextView t = label(name, 24, Color.WHITE, true);
        c.addView(t, lp(-2, -2));
        lg.setAlpha(0f); lg.setTranslationY(px(320));
        t.setAlpha(0f);
        onStart = () -> {
            lg.animate().alpha(1f).translationY(0f).setDuration(1100)
                    .setInterpolator(new BounceInterpolator()).start();
            t.animate().alpha(1f).setStartDelay(700).setDuration(500).start();
        };
    }

    // ---------- S4: Spin-in + bouncing dots ----------
    private void styleSpin() {
        gradient(Color.parseColor("#0BAB64"), Color.parseColor("#3BB78F"),
                GradientDrawable.Orientation.TOP_BOTTOM);
        LinearLayout c = column();
        final ImageView lg = logoView();
        c.addView(lg, lp(110, 110));
        gap(c, 20);
        final TextView t = label(name, 22, Color.WHITE, true);
        c.addView(t, lp(-2, -2));
        gap(c, 28);
        LinearLayout row = new LinearLayout(getContext());
        row.setOrientation(LinearLayout.HORIZONTAL);
        final List<View> dots = new ArrayList<>();
        for (int i = 0; i < 3; i++) {
            View d = new View(getContext());
            d.setBackground(rounded(Color.WHITE, 5));
            LinearLayout.LayoutParams p = lp(10, 10);
            p.leftMargin = px(5); p.rightMargin = px(5);
            row.addView(d, p);
            dots.add(d);
        }
        c.addView(row, lp(-2, -2));
        lg.setAlpha(0f); lg.setScaleX(0f); lg.setScaleY(0f); lg.setRotation(-360f);
        t.setAlpha(0f);
        onStart = () -> {
            lg.animate().alpha(1f).scaleX(1f).scaleY(1f).rotation(0f).setDuration(1100)
                    .setInterpolator(new DecelerateInterpolator()).start();
            t.animate().alpha(1f).setStartDelay(800).setDuration(500).start();
            for (int i = 0; i < dots.size(); i++) {
                ObjectAnimator a = keep(ObjectAnimator.ofFloat(dots.get(i), "translationY", 0f, -px(14)));
                a.setDuration(400);
                a.setRepeatCount(ValueAnimator.INFINITE);
                a.setRepeatMode(ValueAnimator.REVERSE);
                a.setStartDelay(i * 150L);
                a.start();
            }
        };
    }

    // ---------- S5: Minimal + progress line ----------
    private void styleBar() {
        setBackgroundColor(Color.WHITE);
        LinearLayout c = column();
        final ImageView lg = logoView();
        c.addView(lg, lp(100, 100));
        gap(c, 18);
        c.addView(label(name, 20, Color.parseColor("#222222"), true), lp(-2, -2));
        gap(c, 26);
        FrameLayout track = new FrameLayout(getContext());
        track.setBackground(rounded(Color.parseColor("#E6E6E6"), 2));
        final View fill = new View(getContext());
        fill.setBackground(rounded(Color.parseColor("#2979FF"), 2));
        track.addView(fill, new FrameLayout.LayoutParams(-1, -1));
        c.addView(track, lp(160, 4));
        lg.setAlpha(0f);
        fill.setPivotX(0f);
        fill.setScaleX(0.05f);
        onStart = () -> {
            lg.animate().alpha(1f).setDuration(700).start();
            ObjectAnimator a = keep(ObjectAnimator.ofFloat(fill, "scaleX", 0.05f, 1f));
            a.setDuration(1500);
            a.setRepeatCount(ValueAnimator.INFINITE);
            a.setRepeatMode(ValueAnimator.RESTART);
            a.start();
        };
    }
}
