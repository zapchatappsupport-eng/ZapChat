/* Edit only this line, then every page shows your contact email. */
const SITE={email:"YOUR-EMAIL@example.com"};
document.querySelectorAll(".em").forEach(function(a){a.textContent=SITE.email;a.href="mailto:"+SITE.email});
